# Local configuration file for Budget Buddy.
# This file is intentionally ignored by Git and must NOT be committed.
# Replace the placeholder values with your local credentials.

import os

DEBUG = True

MYSQL_HOST = os.environ.get('MYSQL_HOST', 'localhost')
MYSQL_USER = os.environ.get('MYSQL_USER', 'root')
MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD', 'YOUR_MYSQL_PASSWORD')
MYSQL_DB = os.environ.get('MYSQL_DB', 'tracker')
MYSQL_CURSORCLASS = 'DictCursor'

SECRET_KEY = os.environ.get('SECRET_KEY', 'CHANGE_THIS_SECRET_KEY')

MAIL_SERVER = os.environ.get('MAIL_SERVER', 'smtp.googlemail.com')
MAIL_PORT = int(os.environ.get('MAIL_PORT', '587'))
MAIL_USE_TLS = True
MAIL_USERNAME = os.environ.get('EMAIL_USER', 'YOUR_EMAIL')
MAIL_PASSWORD = os.environ.get('EMAIL_PASS', 'YOUR_EMAIL_PASSWORD')
