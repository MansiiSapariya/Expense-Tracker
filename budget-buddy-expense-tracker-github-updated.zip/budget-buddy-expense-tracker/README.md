# Budget Buddy - Expense Tracker

Budget Buddy is a full-stack web application for managing personal finances. It allows users to create accounts, securely log in, record and manage transactions, view transaction history, and visualize spending patterns through charts.

The project was developed as part of the Full Stack Web Development course (MDS273).

## Features

- User registration and login
- Password hashing and session-based authentication
- Add income and expense transactions
- Categorize transactions
- View transaction history
- Filter transactions by month and year
- Edit existing transactions
- Delete transactions
- Category-wise expense visualization
- Current-year vs previous-year comparison
- Monthly expense visualization
- Responsive web interface
- Contact form

The project report describes the application as a practical full-stack solution for personal finance management, with an emphasis on expense tracking, categorization, visualization, security, and responsive design.

## Tech Stack

### Backend

- Python
- Flask
- Flask-MySQLdb
- WTForms
- Passlib
- ItsDangerous

### Frontend

- HTML
- CSS
- JavaScript
- Bootstrap
- jQuery

### Database

- MySQL

### Data Visualization

- Plotly

## Application Workflow

1. A new user creates an account using the Sign Up page.
2. The user's password is securely hashed before being stored.
3. The user logs in through the Login page.
4. Authenticated users can add transactions with an amount, category, and description.
5. Transactions are stored in MySQL and associated with the logged-in user.
6. Users can view, filter, edit, and delete their transactions.
7. The application generates visual summaries of spending by category, month, and year.
8. Users can securely log out when finished.

## Database Design

The application uses a MySQL database named `tracker`.

### users

Stores user account information including:

- `id`
- `first_name`
- `last_name`
- `email`
- `username`
- `password`
- `role`

### transactions

Stores transaction information including:

- `id`
- `user_id`
- `amount`
- `description`
- `category`
- `date`

The `user_id` field links transactions to their corresponding user.

## Project Structure

```text
budget-buddy-expense-tracker/
│
├── README.md
├── requirements.txt
├── .gitignore
├── config.example.py
├── config.py                 # Local only; ignored by Git
├── app.py
├── queries.sql
│
├── templates/
│   ├── layout.html
│   ├── index.html
│   ├── about.html
│   ├── login.html
│   ├── signUp.html
│   ├── addTransactions.html
│   ├── transactionHistory.html
│   ├── editTransaction.html
│   ├── thank_you.html
│   └── includes/
│       ├── _formhelpers.html
│       ├── _messages.html
│       └── _navbar.html
│
├── static/
│   ├── js/
│   ├── styles/
│   └── images and screenshots
│
└── docs/
    └── Project_Report_Full_Stack_Web_Development.pdf
```

## Setup

### 1. Clone the repository

```bash
git clone https://github.com/<your-username>/budget-buddy-expense-tracker.git
cd budget-buddy-expense-tracker
```

### 2. Create a virtual environment

```bash
python -m venv venv
```

Activate it on Windows:

```bash
venv\Scripts\activate
```

On macOS/Linux:

```bash
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure the application

A placeholder `config.py` is included in the downloaded project for local setup. It is ignored by Git and must not be committed. You can also recreate it from `config.example.py`.

```bash
copy config.example.py config.py
```

On macOS/Linux:

```bash
cp config.example.py config.py
```

Then configure your MySQL credentials and Flask secret key using environment variables or your local `config.py`.

Example environment variables:

```text
MYSQL_HOST=localhost
MYSQL_USER=root
MYSQL_PASSWORD=your_mysql_password
MYSQL_DB=tracker
SECRET_KEY=your_secret_key
EMAIL_USER=your_email
EMAIL_PASS=your_email_password
```

**Do not commit `config.py` to GitHub.** It is included in `.gitignore` because it may contain local database credentials and other secrets.

### 5. Set up the database

Create the `tracker` database and run the SQL statements provided in:

```text
queries.sql
```

### 6. Run the application

```bash
python app.py
```

The application runs locally at:

```text
http://localhost:5000
```

## Screenshots

### Sign Up

![Sign Up](static/signup.png)

### Login

![Login](static/login.png)

### Add Transaction

![Add Transaction](static/add.png)

### Transaction History

![Transaction History](static/history.png)

### Category-wise Expense Chart

![Category Chart](static/pie.png)

### Yearly Comparison

![Yearly Comparison](static/comparison.png)

### Monthly Expense Chart

![Monthly Chart](static/line.png)

## Security Note

The original local project configuration contained database credentials. Those credentials have intentionally not been included in this repository version.

Use `config.example.py` as the template for local configuration, and keep the actual `config.py` out of version control.

If credentials from an older local copy have ever been committed to a public repository, they should be rotated immediately.

## Challenges and Learning Outcomes

The project provided practical experience in integrating frontend and backend components, implementing authentication, connecting Flask to MySQL, handling user-specific transaction data, and creating dynamic visualizations. The project report also highlights challenges around technical implementation, data visualization, user experience, and project time management.

## Future Scope

Potential extensions include:

- Budget planning
- Financial goal tracking
- Multi-currency support
- More advanced financial analytics
- Improved dashboard visualizations
- Deployment to a cloud platform

## Documentation

The complete academic project report is available in:

```text
docs/Project_Report_Full_Stack_Web_Development.pdf
```

## Team

- Mansi Sapariya
- Liya Khatija
- Mayank Mehra

## License

This project was developed as an academic project for educational purposes.
